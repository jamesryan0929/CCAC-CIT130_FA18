/*
James Hayes
CIT 130 FA18
Counter Project
*/

/*
CounterView contains main()
*/
//package countermodel;

public class CounterModel {
    
   CounterController counterController = new CounterController();
   
   public void counterModel(int startValue, int stopValue){
       counterController.counterController(startValue, stopValue);
       }
   }
